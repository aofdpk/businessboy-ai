// ลงทะเบียน "สินค้าที่มีอยู่แล้ว" (ไม่ได้สร้างด้วย starter) ให้ใช้กับเพจคิท/ชีทออเดอร์ได้
// ใช้: node tools/init-external.mjs <slug> --title="ชื่อสินค้า" --site=https://... --pro1="โปร 1 · 20 เล่ม 400 หน้า|159|https://.../pro1" --pro2="โปร 2 · 50 เล่ม 1,000 หน้า|199|https://.../pro2" [--emoji=🖍️] [--unit=เล่ม] [--who="ขายให้ใคร"] [--page="ชื่อเพจที่มีอยู่แล้ว"]
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
const args = process.argv.slice(2);
const slug = args.find(a => !a.startsWith('--'));
const opt = k => { const a = args.find(x => x.startsWith('--' + k + '=')); return a ? a.slice(k.length + 3).replace(/^"|"$/g, '') : ''; };
if (!slug || !/^[a-z0-9-]+$/.test(slug)) { console.error('ต้องระบุ slug อังกฤษตัวเล็กมีขีด เช่น coloring-kids-th'); process.exit(1); }
const title = opt('title'), site = opt('site').replace(/\/$/, '');
if (!title || !site) { console.error('ต้องมี --title และ --site'); process.exit(1); }
const promos = ['pro1', 'pro2'].map(k => {
  const v = opt(k); if (!v) return null;
  const [label, price, url] = v.split('|').map(s => s.trim());
  if (!label || !price) { console.error(`--${k} ต้องเป็น "ป้ายโปร|ราคา|ลิงก์โหลด"`); process.exit(1); }
  return { key: k, label, price: Number(String(price).replace(/[^\d.]/g, '')), url: url || `${site}/${k}`, labelCustom: true, items: k === 'pro2' ? 'all' : [], best: k === 'pro2' };
}).filter(Boolean);
if (promos.length < 2) { console.error('ต้องมีทั้ง --pro1 และ --pro2'); process.exit(1); }

const pdir = path.join(root, 'products', slug); fs.mkdirSync(pdir, { recursive: true });
const product = {
  slug, title, emoji: opt('emoji') || '📄', external: true, site, who: opt('who') || '',
  tagline: 'ไฟล์ PDF คมชัด ปริ้นซ้ำได้ไม่จำกัด', note: 'สินค้าที่มีอยู่แล้ว (ไม่ได้สร้างด้วย starter) ใช้ลิงก์เว็บเดิม', unitName: opt('unit') || 'ไฟล์', ratio: '3 / 4',
  items: [], promos,
};
fs.writeFileSync(path.join(pdir, 'product.json'), JSON.stringify(product, null, 2) + '\n');

// site.config.json → product ปัจจุบัน
const cfgP = path.join(root, 'site.config.json');
const cfg = fs.existsSync(cfgP) ? JSON.parse(fs.readFileSync(cfgP, 'utf8')) : {};
cfg.product = slug; fs.writeFileSync(cfgP, JSON.stringify(cfg, null, 2) + '\n');

// BRIEF.md สั้น (สำเนาเดิมเก็บไว้ที่ products/<slug เดิม>/BRIEF.md ถ้ายังไม่มี)
const briefP = path.join(root, 'BRIEF.md');
if (fs.existsSync(briefP)) {
  const old = fs.readFileSync(briefP, 'utf8'); const m = old.match(/slug:\s*([a-z0-9-]+)/);
  if (m && m[1] !== slug && fs.existsSync(path.join(root, 'products', m[1])) && !fs.existsSync(path.join(root, 'products', m[1], 'BRIEF.md'))) fs.writeFileSync(path.join(root, 'products', m[1], 'BRIEF.md'), old);
}
fs.writeFileSync(briefP, `# BRIEF (สินค้าที่มีอยู่แล้ว · ไม่ได้สร้างด้วย starter)

## สินค้า
- slug: ${slug}
- ชื่อสินค้า: ${title}
- ขายให้ใคร / ปัญหาที่แก้: ${product.who || '(ยังไม่ระบุ)'}
- หน่วย: ${product.unitName}

## โปร (ที่ประกาศบนเว็บ)
| โปร | ได้อะไร | ราคา | ลิงก์โหลด (ส่งหลังโอน) |
|---|---|---|---|
${promos.map(p => `| ${p.label} | | ${p.price} บาท | ${p.url} |`).join('\n')}

## เว็บ
- เว็บตัวอย่าง (ส่งลูกค้าดูก่อนซื้อ): ${site}
- ไม่ต้อง build/deploy เว็บสินค้า (ใช้ของเดิม)
${opt('page') ? `\n## เพจ\n- มีเพจแล้ว: ${opt('page')} (มีโปรไฟล์/ปก/คำอธิบายแล้ว ไม่ต้องทำใหม่ เว้นแต่ผู้ใช้สั่ง)\n` : ''}
## สถานะ
- เพจคิท: ยังไม่ทำ
`);

// ทะเบียน
const regArgs = ['page', slug, `title=${title}`, `site=${site}`];
if (opt('page')) regArgs.push(`pageName=${opt('page')}`, 'status=เปิดเพจแล้ว'); else regArgs.push('status=สินค้าที่มีอยู่แล้ว');
execFileSync(process.execPath, [path.join(root, 'tools', 'registry.mjs'), ...regArgs], { stdio: 'inherit' });
console.log(`✓ products/${slug}/product.json (สินค้าภายนอก) · BRIEF.md · site.config.json → ต่อด้วย prompts/pagekit.md ได้เลย`);
