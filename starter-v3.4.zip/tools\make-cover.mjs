// ตัดรูปปกเฟซบุ๊ก: รับรูปกว้าง (เช่น 1536x1024 จาก image_gen) → ครอปกลาง แล้วย่อเป็น 1640x624
// ใช้: node tools/make-cover.mjs <input.png> <output.png>   (+ ทำโปรไฟล์: node tools/make-cover.mjs --profile in.png out.png → 1024x1024 ครอปกลาง)
import { Jimp } from 'jimp';

const args = process.argv.slice(2);
const profile = args[0] === '--profile';
const [inp, out] = profile ? args.slice(1) : args;
if (!inp || !out) { console.error('ใช้: node tools/make-cover.mjs [--profile] <input> <output>'); process.exit(1); }

const W = profile ? 1024 : 1640, H = profile ? 1024 : 624;
const img = await Jimp.read(inp);
const s = Math.max(W / img.width, H / img.height);
img.resize({ w: Math.ceil(img.width * s), h: Math.ceil(img.height * s) });
img.crop({ x: Math.floor((img.width - W) / 2), y: Math.floor((img.height - H) / 2), w: W, h: H });
await img.write(out);
console.log('✓', out, W + 'x' + H, profile ? '(โปรไฟล์)' : '(ปกเฟซบุ๊ก · เนื้อหาสำคัญควรอยู่กลาง 60% ของความกว้าง เพราะมือถือครอปซ้ายขวาอีก)');
