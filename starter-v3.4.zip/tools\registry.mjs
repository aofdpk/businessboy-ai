// ทะเบียนกลางของทุกเพจ (registry.json) + สร้าง PAGES.md ให้อ่านง่าย
// ใช้:
//   node tools/registry.mjs show                          แสดงทะเบียน
//   node tools/registry.mjs sheet <url>                   บันทึกลิงก์ชีทออเดอร์ (ไฟล์เดียวใช้ทุกเพจ)
//   node tools/registry.mjs page <slug> key=value ...     เพิ่ม/แก้เพจ  key: title pageName site kit status
//   ตัวอย่าง: node tools/registry.mjs page thai-animal-coloring-books pageName="สมุดระบายสีเด็ก ไฟล์ PDF" status="เปิดเพจแล้ว"
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
const RJ = path.join(root, 'registry.json'), PM = path.join(root, 'PAGES.md');
const load = () => fs.existsSync(RJ) ? JSON.parse(fs.readFileSync(RJ, 'utf8')) : { sheet: '', pages: [] };
const save = reg => { fs.writeFileSync(RJ, JSON.stringify(reg, null, 2) + '\n'); fs.writeFileSync(PM, render(reg)); };

function render(reg) {
  const rows = reg.pages.map((p, i) => `| ${i + 1} | ${p.slug} | ${p.pageName || '(ยังไม่ตั้ง)'} | ${p.site || ''} | ${p.kit || '(ยังไม่มี)'} | ${p.status || ''} |`).join('\n');
  return `# ทะเบียนเพจ (ศูนย์กลาง · Codex อ่านทุกครั้งที่เปิดโฟลเดอร์)

> ไฟล์นี้สร้างจาก registry.json · แก้ผ่าน \`node tools/registry.mjs ...\` เท่านั้น ห้ามพิมพ์แก้เอง

**ชีทออเดอร์ (Google Sheet ไฟล์เดียวใช้ทุกเพจ):** ${reg.sheet || '(ยังไม่มี · จะสร้างตอน "ทำเพจคิทให้หน่อย" ครั้งแรก)'}

| # | สินค้า (slug) | ชื่อเพจ | เว็บสินค้า | หน้าเพจคิท | สถานะ |
|---|---|---|---|---|---|
${rows || '| | (ยังไม่มีเพจ) | | | | |'}

สถานะที่ใช้: ไอเดีย → ทดลองแล้ว → ผลิตแล้ว x/N → ผลิตครบ → มีเพจคิทแล้ว → เปิดเพจแล้ว
`;
}

// อ่านข้อมูลสินค้าจาก products/ มาเติมให้อัตโนมัติ (title, site)
function autofill(reg) {
  const pdir = path.join(root, 'products');
  if (!fs.existsSync(pdir)) return reg;
  for (const d of fs.readdirSync(pdir)) {
    const pj = path.join(pdir, d, 'product.json'); if (!fs.existsSync(pj)) continue;
    const p = JSON.parse(fs.readFileSync(pj, 'utf8'));
    let e = reg.pages.find(x => x.slug === p.slug);
    if (!e) { e = { slug: p.slug }; reg.pages.push(e); }
    e.title = e.title || p.title; e.site = e.site || `https://${p.slug}.vercel.app`;
  }
  return reg;
}

const [cmd, ...rest] = process.argv.slice(2);
const reg = autofill(load());
if (cmd === 'sheet') { reg.sheet = rest[0] || ''; save(reg); console.log('✓ บันทึกชีทออเดอร์:', reg.sheet); }
else if (cmd === 'page') {
  const slug = rest[0]; if (!slug) { console.error('ต้องระบุ slug'); process.exit(1); }
  let e = reg.pages.find(x => x.slug === slug); if (!e) { e = { slug }; reg.pages.push(e); }
  for (const kv of rest.slice(1)) { const i = kv.indexOf('='); if (i > 0) e[kv.slice(0, i)] = kv.slice(i + 1).replace(/^"|"$/g, ''); }
  save(reg); console.log('✓ อัปเดตเพจ', slug, JSON.stringify(e));
} else { save(reg); console.log(render(reg)); }
