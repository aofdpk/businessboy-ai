// สร้าง "หน้าเพจคิท" เป็นเว็บ 1 หน้า (เปิดจากมือถือ ก๊อปข้อความ โหลดรูป) จาก pagekit/<slug>/ → site/<slug>-kit-xxxx/
// ใช้: node tools/build-kit.mjs [slug]   (ไม่ระบุ = สินค้าใน site.config.json)
// จากนั้น: cd site/<โฟลเดอร์ที่พิมพ์ออกมา> && npx vercel --prod --yes   (deploy ซ้ำ = ลิงก์เดิม เพราะชื่อโฟลเดอร์คงที่ใน pagekit/<slug>/kit.json)
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
const cfg = fs.existsSync(path.join(root, 'site.config.json')) ? JSON.parse(fs.readFileSync(path.join(root, 'site.config.json'), 'utf8')) : {};
const slug = process.argv.slice(2).find(a => !a.startsWith('--')) || cfg.product;
if (!slug) { console.error('ต้องระบุ slug หรือตั้ง product ใน site.config.json'); process.exit(1); }
const kdir = path.join(root, 'pagekit', slug);
if (!fs.existsSync(kdir)) { console.error('ไม่พบ', path.relative(root, kdir), '→ ทำเพจคิทก่อน (prompts/pagekit.md)'); process.exit(1); }
const pj = path.join(root, 'products', slug, 'product.json');
const product = fs.existsSync(pj) ? JSON.parse(fs.readFileSync(pj, 'utf8')) : { title: slug, promos: [] };
const reg = fs.existsSync(path.join(root, 'registry.json')) ? JSON.parse(fs.readFileSync(path.join(root, 'registry.json'), 'utf8')) : { sheet: '', pages: [] };
const regPage = reg.pages.find(p => p.slug === slug) || {};

// โฟลเดอร์ปลายทางคงที่ต่อสินค้า (ต่อท้ายสุ่ม 4 ตัว กันคนเดาลิงก์)
const kj = path.join(kdir, 'kit.json');
let kit = fs.existsSync(kj) ? JSON.parse(fs.readFileSync(kj, 'utf8')) : {};
if (!kit.dir) { kit.dir = `${slug}-kit-${Math.random().toString(36).slice(2, 6)}`; fs.writeFileSync(kj, JSON.stringify(kit, null, 2)); }
const out = path.join(root, 'site', kit.dir);

// ---------- helpers ----------
const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const read = f => fs.existsSync(path.join(kdir, f)) ? fs.readFileSync(path.join(kdir, f), 'utf8') : '';
const clean = s => s.replace(/\*\*(.*?)\*\*/g, '$1').replace(/__(.*?)__/g, '$1').replace(/`([^`]*)`/g, '$1').replace(/^\s*>\s?/gm, '').trim();
function fenced(body) { const m = [...body.matchAll(/```[^\n]*\n([\s\S]*?)```/g)]; return m.length ? m.map(x => x[1].trim()).join('\n\n') : null; }
function sections(md) { // แบ่ง markdown เป็นการ์ดตามหัวข้อ · ถ้ามี code fence ใช้ข้อความในนั้นเป็นตัวก๊อป
  if (!md.trim()) return [];
  const lines = md.split(/\r?\n/); const out = []; let cur = { title: '', body: [] };
  const push = () => {
    const raw = cur.body.join('\n').trim(); if (!cur.title && !raw) return;
    const f = fenced(raw); // ข้อความนอก fence (เช่น "รูปประกอบ: ...") โชว์เป็นหมายเหตุเล็กๆ เหนือตัวก๊อป
    const note = f !== null ? clean(raw.replace(/```[^\n]*\n[\s\S]*?```/g, '').trim()) : '';
    out.push({ title: clean(cur.title), body: f ?? clean(raw), note });
  };
  for (const l of lines) { const m = l.match(/^#{1,4}\s+(.*)/); if (m) { push(); cur = { title: m[1], body: [] }; } else cur.body.push(l); }
  push();
  return out.filter(s => s.body);
}
function cards(md, opts = {}) {
  return sections(md).map(s => `<div class="card"><div class="ch"><b>${esc(s.title || opts.title || '')}</b><button class="cp" data-copy>ก๊อป</button></div>${s.note ? `<div class="nt">${esc(s.note)}</div>` : ''}<pre>${esc(s.body)}</pre></div>`).join('') || `<div class="empty">${esc(opts.empty || 'ยังไม่มี')}</div>`;
}
const img = f => fs.existsSync(path.join(kdir, f));

// ---------- data ----------
const pageMd = read('page.md'), messages = read('messages.md'), images = read('images.md'), character = read('character.md');
// แยก "ต้อนรับ" (ใช้ตอนยิงแอด) ออกจากข้อความตอบแชทอื่นๆ
const msgSecs = sections(messages);
const welcomeSecs = msgSecs.filter(s => /ต้อนรับ/.test(s.title)), otherSecs = msgSecs.filter(s => !/ต้อนรับ/.test(s.title));
const renderCards = (secs, empty) => secs.map(s => `<div class="card"><div class="ch"><b>${esc(s.title)}</b><button class="cp" data-copy>ก๊อป</button></div>${s.note ? `<div class="nt">${esc(s.note)}</div>` : ''}<pre>${esc(s.body)}</pre></div>`).join('') || `<div class="empty">${esc(empty)}</div>`;
const pageName = regPage.pageName || (pageMd.match(/ฟันธง[^\n]*?[:：]\s*(.+)/) || [])[1] || product.title;
let clips = null; const cj = path.join(kdir, 'clips', 'clips.json');
if (fs.existsSync(cj)) { try { clips = JSON.parse(fs.readFileSync(cj, 'utf8')); } catch { clips = null; } }
const clipMds = fs.existsSync(path.join(kdir, 'clips')) ? fs.readdirSync(path.join(kdir, 'clips')).filter(f => /^\d+.*\.md$/.test(f)).sort() : [];
const sheet = reg.sheet || '';
const site = regPage.site || `https://${slug}.vercel.app`;
const promos = (product.promos || []).map(p => `${p.label} · ${p.price} บาท`).join(' / ');

// ---------- copy assets ----------
fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(path.join(out, 'img'), { recursive: true });
for (const f of ['profile.png', 'cover.png', 'character-sheet.png']) if (img(f)) fs.copyFileSync(path.join(kdir, f), path.join(out, 'img', f));

// ---------- clips html ----------
let clipsHtml = '';
if (clips && Array.isArray(clips) && clips.length) {
  // ข้อความ "ก๊อปทั้งเรื่อง": ชื่อเรื่อง → Hook → ทุกฉาก (คำอธิบาย / Image Prompt / Video Prompt / บทพูด) จบที่บทพูดฉากสุดท้าย (ไม่รวมแคปชั่น) วางใน KVid ได้
  const allText = st => [`ชื่อเรื่อง: ${st.title || ''}`, st.hook ? `Hook: ${st.hook}` : '', st.core ? `แก่นของเรื่อง: ${st.core}` : '', st.structure ? `โครงสร้าง: ${st.structure}` : '', '',
    ...(st.scenes || []).map(sc => [`ฉาก ${sc.n}: ${sc.desc || ''}`, `Image Prompt: ${sc.image || ''}`, `Video Prompt: ${sc.video || ''}`, `บทพูด: ${sc.speech || ''}`, ''].join('\n'))].filter(x => x !== null).join('\n').trim();
  clipsHtml = clips.map((st, i) => `<details class="story"${i === 0 ? ' open' : ''}><summary>🎬 เรื่อง ${i + 1}: ${esc(st.title || '')}</summary>
  <div class="all"><button class="btn gold" data-copy-all="all-${i}">⧉ ก๊อปทั้งเรื่อง (ใส่ KVid)</button><textarea class="hid" id="all-${i}" readonly>${esc(allText(st))}</textarea></div>
  ${st.hook ? `<div class="card"><div class="ch"><b>Hook</b><button class="cp" data-copy>ก๊อป</button></div><pre>${esc(st.hook)}</pre></div>` : ''}
  ${(st.scenes || []).map(sc => `<div class="scene"><div class="sh">ฉาก ${esc(sc.n)} · ${esc(sc.desc || '')}</div>
    <div class="card"><div class="ch"><b>Image Prompt</b><button class="cp" data-copy>ก๊อป</button></div><pre>${esc(sc.image || '')}</pre></div>
    <div class="card"><div class="ch"><b>Video Prompt</b><button class="cp" data-copy>ก๊อป</button></div><pre>${esc(sc.video || '')}</pre></div>
    ${sc.speech ? `<div class="card"><div class="ch"><b>บทพูด</b><button class="cp" data-copy>ก๊อป</button></div><pre>${esc(sc.speech)}</pre></div>` : ''}</div>`).join('')}
  ${st.caption ? `<div class="card"><div class="ch"><b>แคปชั่นคลิป</b><button class="cp" data-copy>ก๊อป</button></div><pre>${esc(st.caption)}</pre></div>` : ''}
</details>`).join('');
} else if (clipMds.length) {
  clipsHtml = clipMds.map((f, i) => `<details class="story"${i === 0 ? ' open' : ''}><summary>🎬 ${esc(f.replace(/\.md$/, ''))}</summary>${cards(fs.readFileSync(path.join(kdir, 'clips', f), 'utf8'))}</details>`).join('');
}

const theme = cfg.theme || {};
const themeCss = ':root{' + Object.entries(theme).map(([k, v]) => `--${k}:${v}`).join(';') + '}';
const tpl = fs.readFileSync(path.join(root, 'ref', 'kit.html'), 'utf8');
const html = tpl
  .replace(/\{\{themeCss\}\}/g, themeCss)
  .replace(/\{\{pageName\}\}/g, esc(pageName)).replace(/\{\{title\}\}/g, esc(product.title)).replace(/\{\{emoji\}\}/g, esc(product.emoji || ''))
  .replace(/\{\{site\}\}/g, esc(site)).replace(/\{\{promos\}\}/g, esc(promos))
  .replace(/\{\{sheetBtn\}\}/g, sheet ? `<a class="btn gold" href="${esc(sheet)}" target="_blank">📊 เปิดชีทออเดอร์</a>` : `<span class="btn dim">📊 ชีทออเดอร์ยังไม่ผูก</span>`)
  .replace(/\{\{profileImg\}\}/g, img('profile.png') ? `<div class="im"><img src="img/profile.png" alt="profile"><a class="btn" href="img/profile.png" download="profile.png">⬇️ โหลดรูปโปรไฟล์</a></div>` : '')
  .replace(/\{\{coverImg\}\}/g, img('cover.png') ? `<div class="im wide"><img src="img/cover.png" alt="cover"><a class="btn" href="img/cover.png" download="cover.png">⬇️ โหลดรูปปก</a></div>` : '')
  .replace(/\{\{charImg\}\}/g, img('character-sheet.png') ? `<div class="im wide"><img src="img/character-sheet.png" alt="character sheet"><a class="btn" href="img/character-sheet.png" download="character-sheet.png">⬇️ โหลด Character Sheet (แนบทุกซีนใน Google Flow)</a></div>` : '')
  .replace(/\{\{pageCards\}\}/g, cards(pageMd, { empty: 'ยังไม่มี page.md' }))
  .replace(/\{\{imageCards\}\}/g, images ? cards(images, { title: 'prompt รูป' }) : '')
  .replace(/\{\{welcomeCards\}\}/g, renderCards(welcomeSecs, 'ยังไม่มีข้อความต้อนรับ (หัวข้อ "ต้อนรับ" ใน messages.md)'))
  .replace(/\{\{messageCards\}\}/g, renderCards(otherSecs, 'ยังไม่มีข้อความตอบ'))
  .replace(/\{\{characterCards\}\}/g, character ? cards(character) : '')
  .replace(/\{\{clips\}\}/g, clipsHtml || `<div class="empty">ยังไม่มีบทคลิป · สั่ง "ทำคลิปขายให้หน่อย"</div>`);
fs.writeFileSync(path.join(out, 'index.html'), html, 'utf8');
fs.writeFileSync(path.join(out, 'vercel.json'), JSON.stringify({ cleanUrls: true, trailingSlash: false }, null, 2));
console.log(`✓ สร้าง site/${kit.dir}/ (หน้าเพจคิทของ ${pageName})`);
console.log(`ขึ้นเว็บ: cd site/${kit.dir} && npx vercel --prod --yes   → https://${kit.dir}.vercel.app`);
