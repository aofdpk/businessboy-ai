// ชีทรับออเดอร์ + กำไรขาดทุน หลายเพจ (ExcelJS) → pagekit/orders.xlsx
// ใช้: node tools/make-orders-xlsx.mjs [--rows=1000] [--out=path] [--demo]
//  - อ่านสินค้าทุกตัวใน products/*/product.json มาใส่แท็บ "ตั้งค่า" ให้เอง (1 สินค้า = 1 เพจ) ไม่มีก็ใส่เพจตัวอย่าง
//  - 6 แท็บ: ตั้งค่า / แอดมิน / ออเดอร์ / ค่าแอด / สรุป / รายเดือน  มีดรอปดาวน์ เลือกเพจก่อนค่อยเลือกโปร สีตามสถานะ ROAS แดงเหลืองเขียว
//  - อัปขึ้น Google Drive → เปิดด้วย Google Sheets ได้เลย ดรอปดาวน์/สี/สูตรยังอยู่ (ใช้แต่สูตรที่ Excel และ Google รองรับเหมือนกัน)
import fs from 'node:fs';
import path from 'node:path';
import ExcelJS from 'exceljs';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
const args = process.argv.slice(2);
const opt = k => (args.find(a => a.startsWith('--' + k + '=')) || '').split('=').slice(1).join('=');
const N = Number(opt('rows')) || 1000;      // แถวออเดอร์ / ค่าแอด ที่เตรียมสูตรไว้
const NP = Number(opt('pages')) || 200, NPR = Number(opt('promos')) || 600, NA = Number(opt('admins')) || 50, NCH = 10, K = 6, NDAYS = 30, NMON = 24; // เพจ / โปร / แอดมิน / ช่องทาง / โปรต่อเพจ / วัน / เดือน (--pages= --promos= --admins= ย่อไฟล์ได้)
const DEMO = args.includes('--demo');
const out = opt('out') ? path.resolve(opt('out')) : path.join(root, 'pagekit', DEMO ? 'orders-demo.xlsx' : 'orders.xlsx');

// ---------- ข้อมูลตั้งต้น ----------
const STATUS = ['รอโอน', 'โอนแล้ว', 'ส่งไฟล์แล้ว', 'ยกเลิก', 'คืนเงิน'];
const STATUS_FILL = { 'รอโอน': 'FFFFF2CC', 'โอนแล้ว': 'FFDDEBF7', 'ส่งไฟล์แล้ว': 'FFE2EFDA', 'ยกเลิก': 'FFE7E6E6', 'คืนเงิน': 'FFF8CBAD' };
const CHANNELS = ['Facebook', 'LINE', 'TikTok', 'Instagram'];
const num = s => Number(String(s).replace(/,/g, ''));
const parseLabel = (label, fallbackCount, unit) => { // "โปร 2 · 50 เล่ม 1,000 หน้า" → {name, count, unit, pages}
  const m = String(label).match(/^(.*?)\s*·\s*([\d,]+)\s*(\S+)\s+([\d,]+)\s*หน้า/);
  if (m) return { name: m[1].trim(), count: num(m[2]), unit: m[3], pages: num(m[4]) };
  return { name: String(label).split('·')[0].trim(), count: fallbackCount || '', unit, pages: '' };
};
const REG = fs.existsSync(path.join(root, 'registry.json')) ? JSON.parse(fs.readFileSync(path.join(root, 'registry.json'), 'utf8')) : { pages: [] }; // ชื่อเพจจริงจากทะเบียน
let pages = []; // {name, product, url, promos:[{name, price, count, unit, pages}]}
const pdir = path.join(root, 'products');
if (fs.existsSync(pdir)) for (const d of fs.readdirSync(pdir)) {
  const pj = path.join(pdir, d, 'product.json'); if (!fs.existsSync(pj)) continue;
  const p = JSON.parse(fs.readFileSync(pj, 'utf8'));
  const rp = REG.pages.find(x => x.slug === p.slug) || {};
  pages.push({ name: rp.pageName || p.title, product: p.title, url: rp.site || `https://${p.slug}.vercel.app`, promos: (p.promos || []).map(x => ({ price: x.price, ...parseLabel(x.label, x.count, p.unitName || 'ไฟล์') })) });
}
let admins = [{ name: 'ฉันเอง', page: '', contact: '', com: 0 }];
let demoOrders = [], demoAds = [];
if (DEMO) {
  pages = [
    { name: 'ระบายสีเด็ก', product: 'ชุดสมุดระบายสี สัตว์น้อยเที่ยวเมืองไทย', url: 'https://thai-animal-coloring-books.vercel.app', promos: [{ name: 'โปร 1', price: 159, count: 20, unit: 'เล่ม', pages: 400 }, { name: 'โปร 2', price: 199, count: 50, unit: 'เล่ม', pages: 1000 }] },
    { name: 'ชีทฝึกเขียน ก-ฮ', product: 'ชีทฝึกเขียน ก-ฮ และ A-Z', url: 'https://writing-sheets-demo.vercel.app', promos: [{ name: 'โปร 1', price: 159, count: 15, unit: 'ชุด', pages: 300 }, { name: 'โปร 2', price: 199, count: 40, unit: 'ชุด', pages: 800 }] },
    { name: 'แฟลชการ์ด 2 ภาษา', product: 'แฟลชการ์ดคำศัพท์ ไทย-อังกฤษ', url: 'https://flashcards-demo.vercel.app', promos: [{ name: 'โปร 1', price: 159, count: 10, unit: 'ชุด', pages: 200 }, { name: 'โปร 2', price: 199, count: 30, unit: 'ชุด', pages: 600 }, { name: 'โปร 3 จัดเต็ม', price: 299, count: 60, unit: 'ชุด', pages: 1200 }] },
  ];
  admins = [{ name: 'ฉันเอง', page: 'ระบายสีเด็ก', contact: '', com: 0 }, { name: 'น้องมิ้นท์', page: 'ชีทฝึกเขียน ก-ฮ', contact: 'line: mint', com: 10 }, { name: 'น้องบี', page: 'แฟลชการ์ด 2 ภาษา', contact: '08x-xxx-xxxx', com: 10 }];
  const names = ['คุณแนน', 'คุณบี', 'ครูอ้อ', 'แม่น้องพลอย', 'คุณจอย', 'คุณต้อม', 'ครูนิด', 'คุณฝน', 'คุณเก๋', 'คุณมิ้นท์', 'ครูแพร', 'คุณอุ๋ย', 'แม่น้องไข่มุก', 'คุณปุ๊ก', 'ครูเบียร์', 'คุณส้ม', 'คุณนุช', 'คุณเอ', 'ครูจุ๋ม', 'คุณแอน', 'คุณกิ๊ฟ', 'แม่น้องต้นน้ำ', 'คุณหมิว', 'ครูตาล', 'คุณพลอย'];
  let seed = 7; const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
  const today = new Date(); const day = i => new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate() - i));
  const perDay = [8, 7, 6, 6, 5, 4, 3]; let k = 0;
  perDay.forEach((cnt, i) => {
    for (let j = 0; j < cnt; j++) {
      const pg = pages[k % 3]; const pr = pg.promos[rnd() < 0.25 ? 0 : (pg.promos.length === 3 && rnd() < 0.3 ? 2 : 1)];
      let st = i === 0 ? (j < 2 ? 'รอโอน' : j < 5 ? 'โอนแล้ว' : 'ส่งไฟล์แล้ว') : 'ส่งไฟล์แล้ว';
      if (k === 9) st = 'ยกเลิก'; if (k === 17) st = 'คืนเงิน'; if (k === 22) st = 'ยกเลิก';
      demoOrders.push({ date: day(i), page: pg.name, promo: pr, name: names[k % names.length], ch: CHANNELS[k % 4 === 3 ? 0 : k % 3], admin: admins[k % 3].name, status: st, note: k === 6 ? 'ขอใบเสร็จ' : st === 'ยกเลิก' ? 'ลูกค้าเงียบ' : '' });
      k++;
    }
    pages.forEach((pg, pi) => demoAds.push({ date: day(i), page: pg.name, ad: [260, 110, 170][pi] + (i < 3 ? 40 : 0), other: 0, note: i === 2 && pi === 0 ? 'เพิ่มงบ' : '' }));
  });
}
if (!pages.length) pages = [{ name: 'เพจตัวอย่าง (แก้ได้)', product: 'สินค้าตัวอย่าง', url: '', promos: [{ name: 'โปร 1', price: 159, count: 20, unit: 'ไฟล์', pages: 400 }, { name: 'โปร 2', price: 199, count: 50, unit: 'ไฟล์', pages: 1000 }] }];

// ---------- สไตล์ ----------
const NAVY = 'FF1F3864', GOLD = 'FFFFE699', GOLD2 = 'FFFFF2CC', WHITE = 'FFFFFFFF', RED = 'FFF8CBAD', GREEN = 'FFC6EFCE', YELLOW = 'FFFFEB9C', LINE = 'FFD9D9D9';
const fill = c => ({ type: 'pattern', pattern: 'solid', fgColor: { argb: c } });
const thin = { style: 'thin', color: { argb: LINE } }; const border = { top: thin, left: thin, bottom: thin, right: thin };
const FMT = '#,##0', FMT0 = '#,##0;-#,##0;;@', FMT2 = '0.00', DATE = 'yyyy-mm-dd'; // FMT0 = ซ่อนเลข 0 ในตาราง
const Q = s => `'${s}'`; // ชื่อแท็บในสูตร
function title(ws, text, sub) {
  ws.getCell('A1').value = text; ws.getCell('A1').font = { bold: true, size: 16, color: { argb: NAVY } }; ws.getRow(1).height = 26;
  if (sub) { ws.getCell('A2').value = sub; ws.getCell('A2').font = { italic: true, size: 10, color: { argb: 'FF7F7F7F' } }; }
}
function header(ws, row, col, labels, color = NAVY) {
  labels.forEach((t, i) => { const c = ws.getCell(row, col + i); c.value = t; c.font = { bold: true, color: { argb: color === NAVY ? WHITE : NAVY }, size: 11 }; c.fill = fill(color); c.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true }; c.border = border; });
  ws.getRow(row).height = Math.max(ws.getRow(row).height || 0, 22);
}
function section(ws, row, col, span, text) { // แถบหัวข้อสีทอง
  ws.mergeCells(row, col, row, col + span - 1); const c = ws.getCell(row, col); c.value = text; c.font = { bold: true, size: 12, color: { argb: NAVY } }; c.fill = fill(GOLD); c.alignment = { vertical: 'middle' }; ws.getRow(row).height = 22;
}
function cellF(ws, r, c, formula, fmt) { const cell = ws.getCell(r, c); cell.value = { formula }; if (fmt) cell.numFmt = fmt; cell.border = border; return cell; }
function box(ws, r1, c1, r2, c2) { for (let r = r1; r <= r2; r++) for (let c = c1; c <= c2; c++) ws.getCell(r, c).border = border; }
const L = n => { let s = ''; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; };
function listDV(ws, ref, formula) { ws.dataValidations.add(ref, { type: 'list', allowBlank: true, formulae: [formula], showErrorMessage: false }); }
function dateDV(ws, ref) { ws.dataValidations.add(ref, { type: 'date', operator: 'greaterThan', allowBlank: true, formulae: [new Date(Date.UTC(2020, 0, 1))], showErrorMessage: true, errorTitle: 'วันที่', error: 'พิมพ์เป็นวันที่ เช่น 2026-09-04' }); }
function roasRules(ws, ref, redCell, greenCell) {
  const a = ref.split(':')[0];
  ws.addConditionalFormatting({ ref, rules: [
    { type: 'expression', formulae: [`AND(ISNUMBER(${a}),${a}<${redCell})`], style: { fill: fill(RED), font: { bold: true, color: { argb: 'FF9C0006' } } } },
    { type: 'expression', formulae: [`AND(ISNUMBER(${a}),${a}>=${greenCell})`], style: { fill: fill(GREEN), font: { bold: true, color: { argb: 'FF006100' } } } },
    { type: 'expression', formulae: [`AND(ISNUMBER(${a}),${a}>=${redCell},${a}<${greenCell})`], style: { fill: fill(YELLOW), font: { color: { argb: 'FF9C5700' } } } },
  ] });
}
function scaleRule(ws, ref) { ws.addConditionalFormatting({ ref, rules: [{ type: 'colorScale', cfvo: [{ type: 'min' }, { type: 'max' }], color: [{ argb: 'FFFFFFFF' }, { argb: 'FF63BE7B' }] }] }); }

const wb = new ExcelJS.Workbook(); wb.creator = 'starter'; wb.created = new Date();

// ================= ตั้งค่า =================
const S = wb.addWorksheet('ตั้งค่า', { views: [{ state: 'frozen', ySplit: 4 }] });
title(S, '⚙️ ตั้งค่า', 'กรอกครั้งเดียว: เพจ → โปรของแต่ละเพจ → กฎ · ทุกดรอปดาวน์ในแท็บอื่นดึงจากหน้านี้ · เพิ่มเพจใหม่แค่พิมพ์ต่อลงไป');
// เพจ A-E (แถว 5..204)
section(S, 3, 1, 5, `1) เพจ (ได้ถึง ${NP} เพจ)`);
header(S, 4, 1, ['ลำดับ', 'ชื่อเพจ', 'สินค้า', 'ลิงก์เว็บตัวอย่าง', 'สถานะ']);
const PG1 = 5, PG2 = PG1 + NP - 1;
for (let r = PG1; r <= PG2; r++) {
  cellF(S, r, 1, `IF(B${r}="","",ROW()-${PG1 - 1})`); box(S, r, 2, r, 5);
  const p = pages[r - PG1]; if (p) { S.getCell(r, 2).value = p.name; S.getCell(r, 3).value = p.product; S.getCell(r, 4).value = p.url; S.getCell(r, 5).value = 'เปิด'; }
}
listDV(S, `E${PG1}:E${PG2}`, '"เปิด,ปิด"');
// โปร G-P (แถว 5..604) · N,O,P ซ่อน
section(S, 3, 7, 7, `2) โปรของแต่ละเพจ (เพจละไม่เกิน ${K} โปร · รวมได้ ${NPR} แถว)`);
header(S, 4, 7, ['เพจ', 'ชื่อโปร', 'ราคา', 'จำนวน', 'หน่วย', 'หน้า', 'ป้ายโปร (อัตโนมัติ)', 'key', 'idx', 'key2']);
const PR1 = 5, PR2 = PR1 + NPR - 1;
const promoRows = pages.flatMap(p => p.promos.map(x => ({ page: p.name, ...x })));
for (let r = PR1; r <= PR2; r++) {
  box(S, r, 7, r, 12);
  cellF(S, r, 13, `IF(H${r}="","",H${r}&IF(J${r}<>""," · "&TEXT(J${r},"#,##0")&" "&K${r},"")&IF(L${r}<>""," "&TEXT(L${r},"#,##0")&" หน้า",""))`);
  cellF(S, r, 14, `IF(OR(G${r}="",M${r}=""),"",G${r}&"|"&M${r})`);
  cellF(S, r, 15, `IF(G${r}="","",COUNTIF($G$${PR1}:G${r},G${r}))`);
  cellF(S, r, 16, `IF(G${r}="","",G${r}&"#"&O${r})`);
  S.getCell(r, 9).numFmt = FMT; S.getCell(r, 10).numFmt = FMT; S.getCell(r, 12).numFmt = FMT;
  const x = promoRows[r - PR1]; if (x) { S.getCell(r, 7).value = x.page; S.getCell(r, 8).value = x.name; S.getCell(r, 9).value = x.price; S.getCell(r, 10).value = x.count === '' ? null : x.count; S.getCell(r, 11).value = x.unit; S.getCell(r, 12).value = x.pages === '' ? null : x.pages; }
}
listDV(S, `G${PR1}:G${PR2}`, `${Q('ตั้งค่า')}!$B$${PG1}:$B$${PG2}`);
// กฎ R-S
section(S, 3, 18, 2, '3) กฎ');
S.getCell(4, 18).value = 'ROAS แดง ต่ำกว่า'; S.getCell(4, 19).value = 1.5;
S.getCell(5, 18).value = 'ROAS เขียว ตั้งแต่'; S.getCell(5, 19).value = 2.5;
S.getCell(4, 19).numFmt = FMT2; S.getCell(5, 19).numFmt = FMT2; box(S, 4, 18, 5, 19); S.getCell(4, 19).fill = fill(GOLD2); S.getCell(5, 19).fill = fill(GOLD2);
S.getCell(6, 18).value = 'ต่ำกว่าแดง 2 วันติด = หยุด/เปลี่ยนครีเอทีฟ · ถึงเขียว = เติมงบ 30%'; S.getCell(6, 18).font = { italic: true, size: 9, color: { argb: 'FF7F7F7F' } };
header(S, 8, 18, ['ช่องทางขาย (แก้ได้)']); const CH1 = 9, CH2 = CH1 + NCH - 1;
for (let r = CH1; r <= CH2; r++) { box(S, r, 18, r, 18); const c = CHANNELS[r - CH1]; if (c) S.getCell(r, 18).value = c; }
header(S, 20, 18, ['สถานะ (ห้ามแก้ชื่อ)']); const ST1 = 21, ST2 = ST1 + STATUS.length - 1;
STATUS.forEach((s, i) => { const c = S.getCell(ST1 + i, 18); c.value = s; c.fill = fill(STATUS_FILL[s]); c.border = border; if (s === 'ยกเลิก') c.font = { strike: true, color: { argb: 'FF7F7F7F' } }; });
S.getCell(ST2 + 1, 18).value = 'นับยอดขายเฉพาะ โอนแล้ว + ส่งไฟล์แล้ว'; S.getCell(ST2 + 1, 18).font = { italic: true, size: 9, color: { argb: 'FF7F7F7F' } };
// ตารางช่วย U..AA (ซ่อน): U = ทุกเพจ + ชื่อเพจ · V..AA = โปร 1..6 ของเพจนั้น
const MX = 21; S.getCell(4, MX).value = 'ทุกเพจ';
for (let r = PG1; r <= PG2; r++) {
  cellF(S, r, MX, `IF(B${r}="","",B${r})`);
  for (let k = 1; k <= K; k++) cellF(S, r, MX + k, `IFERROR(INDEX($M$${PR1}:$M$${PR2},MATCH($${L(MX)}${r}&"#${k}",$P$${PR1}:$P$${PR2},0)),"")`);
}
[14, 15, 16].forEach(c => { S.getColumn(c).hidden = true; });
for (let c = MX; c <= MX + K; c++) S.getColumn(c).hidden = true;
[7, 22, 30, 36, 8, 2, 22, 14, 8, 8, 8, 8, 34, 8, 8, 8, 2, 30, 10].forEach((w, i) => S.getColumn(i + 1).width = w);

// ================= แอดมิน =================
const A = wb.addWorksheet('แอดมิน', { views: [{ state: 'frozen', ySplit: 4 }] });
title(A, '👥 แอดมิน', 'ใครตอบแชท/ปิดการขาย · ค่าคอมต่อออเดอร์ใส่เป็นบาท (ว่าง = ไม่มี) · ในสรุปจะคำนวณค่าคอมที่ต้องจ่ายให้เอง');
section(A, 3, 1, 6, `รายชื่อแอดมิน (ได้ถึง ${NA} คน)`);
header(A, 4, 1, ['ลำดับ', 'ชื่อแอดมิน', 'เพจที่ดูแล', 'LINE / เบอร์', 'ค่าคอมต่อออเดอร์ (บาท)', 'สถานะ']);
const AD1 = 5, AD2 = AD1 + NA - 1;
for (let r = AD1; r <= AD2; r++) {
  cellF(A, r, 1, `IF(B${r}="","",ROW()-${AD1 - 1})`); box(A, r, 2, r, 6); A.getCell(r, 5).numFmt = FMT;
  const a = admins[r - AD1]; if (a) { A.getCell(r, 2).value = a.name; A.getCell(r, 3).value = a.page || null; A.getCell(r, 4).value = a.contact || null; A.getCell(r, 5).value = a.com; A.getCell(r, 6).value = 'เปิด'; }
}
listDV(A, `C${AD1}:C${AD2}`, `${Q('ตั้งค่า')}!$B$${PG1}:$B$${PG2}`);
listDV(A, `F${AD1}:F${AD2}`, '"เปิด,ปิด"');
[7, 22, 26, 20, 22, 10].forEach((w, i) => A.getColumn(i + 1).width = w);

// ================= ออเดอร์ =================
const O = wb.addWorksheet('ออเดอร์', { views: [{ state: 'frozen', ySplit: 1 }] });
const OH = ['วันที่', 'เพจ', 'โปร', 'ราคา', 'ชื่อลูกค้า', 'ช่องทาง', 'แอดมิน', 'สถานะ', 'หมายเหตุ', 'ยอดนับ', 'ค่าคอม', 'เดือน', 'เพจนับ', ...Array.from({ length: K }, (_, i) => 'โปร' + (i + 1))];
header(O, 1, 1, OH); O.getRow(1).height = 26;
const O1 = 2, O2 = O1 + N - 1, HP = 14; // HP = คอลัมน์แรกของโปรช่วย (N)
for (let r = O1; r <= O2; r++) {
  box(O, r, 1, r, 9); O.getCell(r, 1).numFmt = DATE;
  cellF(O, r, 4, `IF(OR(B${r}="",C${r}=""),"",IFERROR(INDEX(${Q('ตั้งค่า')}!$I$${PR1}:$I$${PR2},MATCH(B${r}&"|"&C${r},${Q('ตั้งค่า')}!$N$${PR1}:$N$${PR2},0)),""))`, FMT);
  cellF(O, r, 10, `IF(AND(ISNUMBER(D${r}),OR(H${r}="โอนแล้ว",H${r}="ส่งไฟล์แล้ว")),D${r},0)`, FMT);
  cellF(O, r, 11, `IF(AND(J${r}>0,G${r}<>""),N(IFERROR(VLOOKUP(G${r},${Q('แอดมิน')}!$B$${AD1}:$E$${AD2},4,FALSE),0)),0)`, FMT);
  cellF(O, r, 12, `IF(A${r}="","",TEXT(A${r},"yyyy-mm"))`);
  cellF(O, r, 13, `IF(B${r}="","(ไม่ระบุ)",B${r})`);
  for (let k = 1; k <= K; k++) cellF(O, r, HP + k - 1, `IFERROR(INDEX(${Q('ตั้งค่า')}!$${L(MX + 1)}$${PG1}:$${L(MX + K)}$${PG2},MATCH($B${r},${Q('ตั้งค่า')}!$${L(MX)}$${PG1}:$${L(MX)}$${PG2},0),${k}),"")`);
  listDV(O, `C${r}`, `$${L(HP)}${r}:$${L(HP + K - 1)}${r}`); // ดรอปดาวน์โปร เฉพาะของเพจในแถวนี้
}
dateDV(O, `A${O1}:A${O2}`);
listDV(O, `B${O1}:B${O2}`, `${Q('ตั้งค่า')}!$B$${PG1}:$B$${PG2}`);
listDV(O, `F${O1}:F${O2}`, `${Q('ตั้งค่า')}!$R$${CH1}:$R$${CH2}`);
listDV(O, `G${O1}:G${O2}`, `${Q('แอดมิน')}!$B$${AD1}:$B$${AD2}`);
listDV(O, `H${O1}:H${O2}`, `${Q('ตั้งค่า')}!$R$${ST1}:$R$${ST2}`);
for (let c = 10; c <= HP + K - 1; c++) O.getColumn(c).hidden = true;
[12, 22, 30, 9, 20, 12, 14, 13, 24].forEach((w, i) => O.getColumn(i + 1).width = w);
O.addConditionalFormatting({ ref: `A${O1}:I${O2}`, rules: [
  ...STATUS.map((s, i) => ({ type: 'expression', priority: i + 1, formulae: [`$H${O1}="${s}"`], stopIfTrue: true, style: { fill: fill(STATUS_FILL[s]), font: s === 'ยกเลิก' ? { strike: true, color: { argb: 'FF7F7F7F' } } : s === 'คืนเงิน' ? { color: { argb: 'FF9C0006' } } : undefined } })),
  { type: 'expression', priority: 9, formulae: [`MOD(ROW(),2)=0`], style: { fill: fill('FFF9F9F9') } },
] });
O.addConditionalFormatting({ ref: `C${O1}:C${O2}`, rules: [{ type: 'expression', priority: 0, formulae: [`AND($C${O1}<>"",$D${O1}="")`], style: { fill: fill('FFFF0000'), font: { bold: true, color: { argb: WHITE } } } }] }); // โปรไม่ตรงเพจ
O.addConditionalFormatting({ ref: `H${O1}:H${O2}`, rules: [{ type: 'expression', priority: 0, formulae: [`AND($B${O1}<>"",$H${O1}="")`], style: { fill: fill('FFFFC7CE') } }] }); // ลืมใส่สถานะ
// ข้อมูลตัวอย่าง
const ptxt = x => `${x.name}${x.count !== '' ? ` · ${Number(x.count).toLocaleString('en-US')} ${x.unit}` : ''}${x.pages !== '' ? ` ${Number(x.pages).toLocaleString('en-US')} หน้า` : ''}`;
const todayUTC = new Date(Date.UTC(new Date().getFullYear(), new Date().getMonth(), new Date().getDate()));
const ORD = DEMO ? demoOrders : [
  { date: todayUTC, page: pages[0].name, promo: pages[0].promos[1] || pages[0].promos[0], name: 'ตัวอย่าง ลบได้', ch: 'Facebook', admin: admins[0].name, status: 'ส่งไฟล์แล้ว', note: '' },
  { date: todayUTC, page: pages[0].name, promo: pages[0].promos[0], name: 'ตัวอย่าง ลบได้', ch: 'LINE', admin: admins[0].name, status: 'รอโอน', note: '' },
];
ORD.forEach((o, i) => { const r = O1 + i; O.getCell(r, 1).value = o.date; O.getCell(r, 2).value = o.page; O.getCell(r, 3).value = ptxt(o.promo); O.getCell(r, 5).value = o.name; O.getCell(r, 6).value = o.ch; O.getCell(r, 7).value = o.admin; O.getCell(r, 8).value = o.status; O.getCell(r, 9).value = o.note || null; });

// ================= ค่าแอด =================
const D = wb.addWorksheet('ค่าแอด', { views: [{ state: 'frozen', ySplit: 1 }] });
header(D, 1, 1, ['วันที่', 'เพจ', 'ค่าแอด', 'ต้นทุนอื่น', 'หมายเหตุ', 'เดือน', 'เพจนับ']); D.getRow(1).height = 26;
for (let r = O1; r <= O2; r++) {
  box(D, r, 1, r, 5); D.getCell(r, 1).numFmt = DATE; D.getCell(r, 3).numFmt = FMT; D.getCell(r, 4).numFmt = FMT;
  cellF(D, r, 6, `IF(A${r}="","",TEXT(A${r},"yyyy-mm"))`); cellF(D, r, 7, `IF(B${r}="","(ไม่ระบุ)",B${r})`);
}
dateDV(D, `A${O1}:A${O2}`); listDV(D, `B${O1}:B${O2}`, `${Q('ตั้งค่า')}!$B$${PG1}:$B$${PG2}`);
D.getColumn(6).hidden = true; D.getColumn(7).hidden = true;
[12, 22, 10, 10, 26].forEach((w, i) => D.getColumn(i + 1).width = w);
D.addConditionalFormatting({ ref: `A${O1}:E${O2}`, rules: [{ type: 'expression', formulae: [`MOD(ROW(),2)=0`], style: { fill: fill('FFF9F9F9') } }] });
const ADS = DEMO ? demoAds : [{ date: todayUTC, page: pages[0].name, ad: 500, other: 0, note: 'ตัวอย่าง ลบได้' }];
ADS.forEach((a, i) => { const r = O1 + i; D.getCell(r, 1).value = a.date; D.getCell(r, 2).value = a.page; D.getCell(r, 3).value = a.ad; D.getCell(r, 4).value = a.other; D.getCell(r, 5).value = a.note || null; });

// ================= สรุป =================
const R = wb.addWorksheet('สรุป');
title(R, '📊 สรุป', null);
R.getCell('A2').value = 'ดูเพจ ▶'; R.getCell('A2').font = { bold: true }; R.getCell('B2').value = 'ทุกเพจ'; R.getCell('B2').fill = fill(GOLD2); R.getCell('B2').border = border; R.getCell('B2').font = { bold: true };
listDV(R, 'B2', `${Q('ตั้งค่า')}!$${L(MX)}$4:$${L(MX)}$${PG2}`);
cellF(R, 2, 3, `IF(B2="ทุกเพจ","*",B2)`); R.getCell('C2').font = { color: { argb: 'FFBFBFBF' }, size: 8 };
R.getCell('D2').value = 'ROAS แดง <'; cellF(R, 2, 5, `${Q('ตั้งค่า')}!$S$4`, FMT2); R.getCell('F2').value = 'เขียว ≥'; cellF(R, 2, 7, `${Q('ตั้งค่า')}!$S$5`, FMT2);
['D2', 'F2'].forEach(a => { R.getCell(a).font = { size: 9, color: { argb: 'FF7F7F7F' } }; R.getCell(a).alignment = { horizontal: 'right' }; });
const P = '$C$2', OM = `${Q('ออเดอร์')}!$M:$M`, OJ = `${Q('ออเดอร์')}!$J:$J`, OK_ = `${Q('ออเดอร์')}!$K:$K`, OD = `${Q('ออเดอร์')}!$D:$D`, OHs = `${Q('ออเดอร์')}!$H:$H`, OA = `${Q('ออเดอร์')}!$A:$A`, OB = `${Q('ออเดอร์')}!$B:$B`, OC = `${Q('ออเดอร์')}!$C:$C`, OF = `${Q('ออเดอร์')}!$F:$F`, OG = `${Q('ออเดอร์')}!$G:$G`, OL = `${Q('ออเดอร์')}!$L:$L`;
const AG = `${Q('ค่าแอด')}!$G:$G`, AC = `${Q('ค่าแอด')}!$C:$C`, AD_ = `${Q('ค่าแอด')}!$D:$D`, AA = `${Q('ค่าแอด')}!$A:$A`, AB = `${Q('ค่าแอด')}!$B:$B`, AF = `${Q('ค่าแอด')}!$F:$F`;
const cards = [
  ['ยอดขาย (บาท)', `SUMIFS(${OJ},${OM},${P})`, FMT], ['ค่าแอด + ต้นทุน', `SUMIFS(${AC},${AG},${P})+SUMIFS(${AD_},${AG},${P})`, FMT],
  ['ค่าคอมแอดมิน', `SUMIFS(${OK_},${OM},${P})`, FMT], ['กำไรสุทธิ', `A5-C5-E5`, FMT],
  ['ROAS', `IFERROR(ROUND(A5/C5,2),0)`, FMT2], ['ออเดอร์ (ที่จ่ายแล้ว)', `COUNTIFS(${OM},${P},${OJ},">0")`, FMT],
  ['ยอดค้างโอน (รอโอน)', `SUMIFS(${OD},${OM},${P},${OHs},"รอโอน")`, FMT], ['งานค้างส่งไฟล์ (โอนแล้ว)', `COUNTIFS(${OM},${P},${OHs},"โอนแล้ว")`, FMT],
];
cards.forEach(([lab, f, fmt], i) => {
  const r = i < 4 ? 4 : 7, c = 1 + (i % 4) * 2;
  R.mergeCells(r, c, r, c + 1); R.mergeCells(r + 1, c, r + 1, c + 1);
  const lc = R.getCell(r, c); lc.value = lab; lc.font = { size: 10, color: { argb: NAVY }, bold: true }; lc.fill = fill(GOLD); lc.alignment = { horizontal: 'center', vertical: 'middle' };
  const vc = cellF(R, r + 1, c, f, fmt); vc.font = { size: 20, bold: true, color: { argb: NAVY } }; vc.fill = fill(GOLD2); vc.alignment = { horizontal: 'center', vertical: 'middle' };
  R.getRow(r + 1).height = 34;
  for (const cc of [c, c + 1]) { R.getCell(r, cc).border = border; R.getCell(r + 1, cc).border = border; }
});
roasRules(R, 'A8:B8', '$E$2', '$G$2');
R.getCell('A10').value = 'กฎ: ROAS ต่ำกว่าแดง 2 วันติด = หยุด/เปลี่ยนครีเอทีฟ · ถึงเขียว = เติมงบ 30% · กำไรสุทธิ = ยอดขาย - ค่าแอด - ค่าคอม · ยกเลิก/คืนเงิน ไม่ถูกนับ'; R.getCell('A10').font = { italic: true, size: 9, color: { argb: 'FF7F7F7F' } };
// รายวัน A-F
section(R, 12, 1, 6, `รายวัน ${NDAYS} วันล่าสุด`); header(R, 13, 1, ['วันที่', 'ออเดอร์', 'ยอดขาย', 'ค่าแอด', 'กำไร', 'ROAS']);
const DY1 = 14, DY2 = DY1 + NDAYS - 1;
for (let i = 0; i < NDAYS; i++) {
  const r = DY1 + i;
  cellF(R, r, 1, `TODAY()-${i}`, DATE);
  cellF(R, r, 2, `COUNTIFS(${OA},$A${r},${OM},${P},${OJ},">0")`, FMT0);
  cellF(R, r, 3, `SUMIFS(${OJ},${OA},$A${r},${OM},${P})`, FMT0);
  cellF(R, r, 4, `SUMIFS(${AC},${AA},$A${r},${AG},${P})+SUMIFS(${AD_},${AA},$A${r},${AG},${P})`, FMT0);
  cellF(R, r, 5, `C${r}-D${r}-SUMIFS(${OK_},${OA},$A${r},${OM},${P})`, FMT0);
  cellF(R, r, 6, `IF(AND(C${r}=0,D${r}=0),"",IF(D${r}=0,"-",ROUND(C${r}/D${r},2)))`, FMT2);
}
roasRules(R, `F${DY1}:F${DY2}`, '$E$2', '$G$2'); scaleRule(R, `C${DY1}:C${DY2}`);
// รายโปร A-D
const PM0 = DY2 + 2; section(R, PM0, 1, 6, 'รายโปร (เลือกเพจที่ช่อง ดูเพจ ด้านบน)'); header(R, PM0 + 1, 1, ['โปร', 'ออเดอร์', 'ยอดขาย', 'สัดส่วน']);
const MXR = `${Q('ตั้งค่า')}!$${L(MX + 1)}$${PG1}:$${L(MX + K)}$${PG2}`, MXC = `${Q('ตั้งค่า')}!$${L(MX)}$${PG1}:$${L(MX)}$${PG2}`;
for (let k = 1; k <= K; k++) {
  const r = PM0 + 1 + k;
  cellF(R, r, 1, `IF($B$2="ทุกเพจ",${k === 1 ? '"← เลือกเพจก่อน"' : '""'},IFERROR(INDEX(${MXR},MATCH($B$2,${MXC},0),${k}),""))`);
  cellF(R, r, 2, `IF(OR($B$2="ทุกเพจ",A${r}=""),"",COUNTIFS(${OM},${P},${OC},A${r},${OJ},">0"))`, FMT0);
  cellF(R, r, 3, `IF(OR($B$2="ทุกเพจ",A${r}=""),"",SUMIFS(${OJ},${OM},${P},${OC},A${r}))`, FMT0);
  cellF(R, r, 4, `IF(OR($B$2="ทุกเพจ",A${r}=""),"",IFERROR(B${r}/$C$8,0))`, '0%');
}
// รายช่องทาง A-D
const CN0 = PM0 + K + 3; section(R, CN0, 1, 6, 'รายช่องทาง'); header(R, CN0 + 1, 1, ['ช่องทาง', 'ออเดอร์', 'ยอดขาย', 'สัดส่วน']);
for (let i = 0; i < NCH; i++) {
  const r = CN0 + 2 + i;
  cellF(R, r, 1, `IF(${Q('ตั้งค่า')}!R${CH1 + i}="","",${Q('ตั้งค่า')}!R${CH1 + i})`);
  cellF(R, r, 2, `IF(A${r}="","",COUNTIFS(${OM},${P},${OF},A${r},${OJ},">0"))`, FMT0);
  cellF(R, r, 3, `IF(A${r}="","",SUMIFS(${OJ},${OM},${P},${OF},A${r}))`, FMT0);
  cellF(R, r, 4, `IF(A${r}="","",IFERROR(B${r}/$C$8,0))`, '0%');
}
// รายเพจ H-M
section(R, 12, 8, 6, 'รายเพจ'); header(R, 13, 8, ['เพจ', 'ออเดอร์', 'ยอดขาย', 'ค่าแอด', 'กำไร', 'ROAS']);
const PE1 = 14, PE2 = PE1 + NP - 1;
for (let i = 0; i < NP; i++) {
  const r = PE1 + i, sr = PG1 + i;
  cellF(R, r, 8, `IF(${Q('ตั้งค่า')}!B${sr}="","",${Q('ตั้งค่า')}!B${sr})`);
  cellF(R, r, 9, `IF($H${r}="","",COUNTIFS(${OB},$H${r},${OJ},">0"))`, FMT0);
  cellF(R, r, 10, `IF($H${r}="","",SUMIFS(${OJ},${OB},$H${r}))`, FMT0);
  cellF(R, r, 11, `IF($H${r}="","",SUMIFS(${AC},${AB},$H${r})+SUMIFS(${AD_},${AB},$H${r}))`, FMT0);
  cellF(R, r, 12, `IF($H${r}="","",J${r}-K${r}-SUMIFS(${OK_},${OB},$H${r}))`, FMT0);
  cellF(R, r, 13, `IF($H${r}="","",IF(AND(J${r}=0,K${r}=0),"",IF(K${r}=0,"-",ROUND(J${r}/K${r},2))))`, FMT2);
}
roasRules(R, `M${PE1}:M${PE2}`, '$E$2', '$G$2'); scaleRule(R, `J${PE1}:J${PE2}`);
// รายแอดมิน O-R
section(R, 12, 15, 4, 'รายแอดมิน'); header(R, 13, 15, ['แอดมิน', 'ออเดอร์', 'ยอดขาย', 'ค่าคอมที่ต้องจ่าย']);
for (let i = 0; i < NA; i++) {
  const r = 14 + i, ar = AD1 + i;
  cellF(R, r, 15, `IF(${Q('แอดมิน')}!B${ar}="","",${Q('แอดมิน')}!B${ar})`);
  cellF(R, r, 16, `IF($O${r}="","",COUNTIFS(${OG},$O${r},${OM},${P},${OJ},">0"))`, FMT0);
  cellF(R, r, 17, `IF($O${r}="","",SUMIFS(${OJ},${OG},$O${r},${OM},${P}))`, FMT0);
  cellF(R, r, 18, `IF($O${r}="","",SUMIFS(${OK_},${OG},$O${r},${OM},${P}))`, FMT0);
}
scaleRule(R, `Q14:Q${14 + NA - 1}`);
[14, 12, 12, 12, 12, 8, 3, 26, 9, 12, 12, 12, 8, 3, 20, 9, 12, 19].forEach((w, i) => R.getColumn(i + 1).width = w);

// ================= รายเดือน =================
const M = wb.addWorksheet('รายเดือน');
title(M, '📅 รายเดือน', null);
M.getCell('A2').value = 'ดูเพจ ▶'; M.getCell('A2').font = { bold: true }; M.getCell('B2').value = 'ทุกเพจ'; M.getCell('B2').fill = fill(GOLD2); M.getCell('B2').border = border; M.getCell('B2').font = { bold: true };
listDV(M, 'B2', `${Q('ตั้งค่า')}!$${L(MX)}$4:$${L(MX)}$${PG2}`); cellF(M, 2, 3, `IF(B2="ทุกเพจ","*",B2)`); M.getCell('C2').font = { color: { argb: 'FFBFBFBF' }, size: 8 };
cellF(M, 2, 5, `${Q('ตั้งค่า')}!$S$4`, FMT2); cellF(M, 2, 7, `${Q('ตั้งค่า')}!$S$5`, FMT2); ['E2', 'G2'].forEach(a => M.getCell(a).font = { color: { argb: 'FFBFBFBF' }, size: 8 });
header(M, 4, 1, ['เดือน', 'ออเดอร์', 'ยอดขาย', 'ค่าแอด', 'ค่าคอม', 'กำไรสุทธิ', 'ROAS']);
const PM = '$C$2';
for (let i = 0; i < NMON; i++) {
  const r = 5 + i;
  cellF(M, r, 1, `TEXT(EDATE(DATE(YEAR(TODAY()),MONTH(TODAY()),1),-${i}),"yyyy-mm")`);
  cellF(M, r, 2, `COUNTIFS(${OL},$A${r},${OM},${PM},${OJ},">0")`, FMT0);
  cellF(M, r, 3, `SUMIFS(${OJ},${OL},$A${r},${OM},${PM})`, FMT0);
  cellF(M, r, 4, `SUMIFS(${AC},${AF},$A${r},${AG},${PM})+SUMIFS(${AD_},${AF},$A${r},${AG},${PM})`, FMT0);
  cellF(M, r, 5, `SUMIFS(${OK_},${OL},$A${r},${OM},${PM})`, FMT0);
  cellF(M, r, 6, `C${r}-D${r}-E${r}`, FMT0);
  cellF(M, r, 7, `IF(AND(C${r}=0,D${r}=0),"",IF(D${r}=0,"-",ROUND(C${r}/D${r},2)))`, FMT2);
}
roasRules(M, `G5:G${4 + NMON}`, '$E$2', '$G$2'); scaleRule(M, `C5:C${4 + NMON}`);
[12, 10, 12, 12, 10, 12, 8].forEach((w, i) => M.getColumn(i + 1).width = w);

fs.mkdirSync(path.dirname(out), { recursive: true });
await wb.xlsx.writeFile(out);
console.log(`✓ ${path.relative(root, out)} · 6 แท็บ (ตั้งค่า / แอดมิน / ออเดอร์ / ค่าแอด / สรุป / รายเดือน) · เพจ ${pages.length} · โปร ${promoRows.length} · แถวออเดอร์ ${N}${DEMO ? ' · ข้อมูลเดโม่ ' + demoOrders.length + ' ออเดอร์' : ''}`);
console.log('อัปขึ้น Google Drive → เปิดด้วย Google Sheets ได้เลย (ดรอปดาวน์/สี/สูตรยังอยู่) · หรือเปิดใน Excel');
