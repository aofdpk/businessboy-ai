// แปลง pagekit/<slug>/clips/clips.json → pagekit/<slug>/clips/clips.xlsx (1 เรื่อง = 1 แท็บ)
// ใช้: node tools/make-clips-xlsx.mjs [slug]   (ไม่ระบุ = product ใน site.config.json)
import fs from 'node:fs';
import path from 'node:path';
import XLSX from 'xlsx';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
const cfg = fs.existsSync(path.join(root, 'site.config.json')) ? JSON.parse(fs.readFileSync(path.join(root, 'site.config.json'), 'utf8')) : {};
const slug = process.argv[2] || cfg.product;
const src = path.join(root, 'pagekit', slug, 'clips', 'clips.json');
if (!fs.existsSync(src)) { console.error('ไม่พบ', src, '→ ให้ Codex เขียน clips.json ก่อน'); process.exit(1); }
const stories = JSON.parse(fs.readFileSync(src, 'utf8'));
if (!Array.isArray(stories) || !stories.length) { console.error('clips.json ต้องเป็น array ของเรื่อง'); process.exit(1); }

const safe = s => String(s).replace(/[\[\]:*?/\\]/g, '-').replace(/[\x00-\x1f]/g, '').slice(0, 31); // Excel จำกัดชื่อแท็บ 31 ตัว
const wb = XLSX.utils.book_new();
stories.forEach((st, i) => {
  const rows = [
    ['ชื่อเรื่อง', st.title || ''],
    ['Hook หลัก', st.hook || ''],
    ['แก่นของเรื่อง', st.core || ''],
    ['โครงสร้างที่ใช้และการแบ่งช่วงตามฉาก', st.structure || ''],
    ['แคปชั่น', st.caption || ''],
    [],
    ['ลำดับฉาก', 'คำอธิบายฉาก', 'Image Prompt', 'Video Prompt', 'บทพูดภาษาไทย'],
    ...(st.scenes || []).map(sc => [sc.n, sc.desc, sc.image, sc.video, sc.speech]),
  ];
  const ws = XLSX.utils.aoa_to_sheet(rows);
  ws['!cols'] = [{ wch: 10 }, { wch: 40 }, { wch: 70 }, { wch: 70 }, { wch: 40 }];
  ws['!freeze'] = { xSplit: 0, ySplit: 7 };
  XLSX.utils.book_append_sheet(wb, ws, safe(String(i + 1).padStart(2, '0') + ' - ' + (st.title || 'เรื่อง')));
});
const out = path.join(root, 'pagekit', slug, 'clips', 'clips.xlsx');
XLSX.writeFile(wb, out, { compression: true });
const scenes = stories.reduce((s, x) => s + (x.scenes || []).length, 0);
console.log('✓ pagekit/' + slug + '/clips/clips.xlsx ·', stories.length, 'เรื่อง ·', scenes, 'ฉาก · แท็บละเรื่อง');
