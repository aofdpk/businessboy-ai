// ประกอบสินค้า: PNG หน้าต่างๆ → PDF ต่อเล่ม + thumbnail + zip ต่อโปร + อัปเดต product.json
// ใช้: node tools/finalize.mjs <slug>
import fs from 'node:fs';
import path from 'node:path';
import { PDFDocument } from 'pdf-lib';
import { Jimp } from 'jimp';
import archiver from 'archiver';

const slug = process.argv[2];
if (!slug) { console.error('ใช้: node tools/finalize.mjs <slug>'); process.exit(1); }

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
const dir = path.join(root, 'products', slug);
const pj = path.join(dir, 'product.json');
if (!fs.existsSync(pj)) { console.error('ไม่พบ', pj, '→ รัน init-product ก่อน'); process.exit(1); }
const product = JSON.parse(fs.readFileSync(pj, 'utf8'));

const A4 = [595.28, 841.89];
const pagesRoot = path.join(dir, 'pages');
const isImg = f => /\.(png|jpe?g)$/i.test(f);
const numKey = f => { const m = f.match(/(\d+)/); return m ? +m[1] : 0; };

// 1) รายชื่อเล่ม = โฟลเดอร์ใน pages/ (เรียงตามชื่อ) · ถ้า product.json มี items อยู่แล้วใช้ชื่อจากนั้น
const folders = fs.existsSync(pagesRoot) ? fs.readdirSync(pagesRoot).filter(f => fs.statSync(path.join(pagesRoot, f)).isDirectory()).sort() : [];
if (!folders.length) { console.error('ไม่มีโฟลเดอร์เล่มใน', pagesRoot); process.exit(1); }
const known = new Map((product.items || []).map(i => [i.id, i]));
const items = [];
const problems = [];

for (const id of folders) {
  const pdir = path.join(pagesRoot, id);
  const all = fs.readdirSync(pdir).filter(isImg);
  const cover = all.find(f => /^cover\./i.test(f));
  const pages = all.filter(f => !/^cover\./i.test(f)).sort((a, b) => numKey(a) - numKey(b) || a.localeCompare(b));
  if (!pages.length) { problems.push(id + ': ไม่มีหน้า (p01.png ...)'); continue; }

  // PDF: ปก (ถ้ามี) + ทุกหน้า ขนาด A4 แนวตั้ง ใส่รูปเต็มหน้าแบบรักษาสัดส่วน
  const pdf = await PDFDocument.create();
  for (const f of [cover, ...pages].filter(Boolean)) {
    const buf = fs.readFileSync(path.join(pdir, f));
    const img = /\.png$/i.test(f) ? await pdf.embedPng(buf) : await pdf.embedJpg(buf);
    const page = pdf.addPage(A4);
    const s = Math.min(A4[0] / img.width, A4[1] / img.height);
    const w = img.width * s, h = img.height * s;
    page.drawImage(img, { x: (A4[0] - w) / 2, y: (A4[1] - h) / 2, width: w, height: h });
  }
  fs.mkdirSync(path.join(dir, 'files'), { recursive: true });
  const pdfName = id + '.pdf';
  fs.writeFileSync(path.join(dir, 'files', pdfName), await pdf.save());

  // thumbnail: ใช้หน้าแรก (ไม่ใช่ปก เพราะลูกค้าอยากเห็นข้างใน) ย่อกว้าง 480
  fs.mkdirSync(path.join(dir, 'thumbs'), { recursive: true });
  const th = await Jimp.read(path.join(pdir, pages[0]));
  th.resize({ w: 480 });
  await th.write(path.join(dir, 'thumbs', id + '.jpg'), { quality: 82 });

  const prev = known.get(id) || {};
  // ชื่อไฟล์ที่ลูกค้าเห็นตอนโหลด = ชื่อเล่ม (ตั้ง dlCustom:true ถ้าอยากล็อกชื่อเอง)
  const dlBase = (prev.dlCustom && prev.dl ? prev.dl : (prev.name || id)).replace(/(\.pdf)+$/i, '').replace(/[\\/:*?"<>|]/g, '-');
  items.push({ id, name: prev.name || id, pages: pages.length, file: 'files/' + pdfName, thumb: 'thumbs/' + id + '.jpg', dl: dlBase + '.pdf' });
  console.log('✓', id, pages.length, 'หน้า', cover ? '+ปก' : '(ไม่มีปก)');
}
product.items = items;

// 2) โปร: "all" = ทุกเล่ม · array = รายชื่อ id · ถ้า array ว่างของ pro1 ให้เติมครึ่งแรกอัตโนมัติ
//    label เขียนให้อัตโนมัติตามจำนวนจริง ("โปร 1 · 3 เล่ม") เว้นแต่ตั้ง labelCustom:true
const unit = product.unitName || 'เล่ม';
(product.promos || []).forEach((p, idx) => {
  if (p.items !== 'all') {
    if (!Array.isArray(p.items) || !p.items.length) p.items = items.slice(0, Math.max(1, Math.ceil(items.length / 2))).map(i => i.id);
    const missing = p.items.filter(id => !items.find(i => i.id === id));
    if (missing.length) problems.push(p.key + ': ไม่พบเล่ม ' + missing.join(', '));
  }
  const n = p.items === 'all' ? items.length : p.items.length;
  if (!p.labelCustom) p.label = `โปร ${idx + 1} · ${p.items === 'all' ? 'ครบ ' : ''}${n} ${unit}`;
});

// 3) zip ต่อโปร (ชื่อไฟล์ในซิปเป็นชื่อไทยที่ลูกค้าอ่านรู้เรื่อง)
fs.mkdirSync(path.join(dir, 'zips'), { recursive: true });
for (const p of product.promos || []) {
  const list = p.items === 'all' ? items : items.filter(i => p.items.includes(i.id));
  const out = path.join(dir, 'zips', p.key + '.zip');
  await new Promise((res, rej) => {
    const o = fs.createWriteStream(out); const a = archiver('zip', { zlib: { level: 6 } });
    o.on('close', res); a.on('error', rej); a.pipe(o);
    for (const i of list) a.file(path.join(dir, i.file), { name: i.dl });
    a.finalize();
  });
  p.count = list.length;
  console.log('✓ zip', p.key, list.length, 'ไฟล์', (fs.statSync(out).size / 1e6).toFixed(1) + 'MB');
}

fs.writeFileSync(pj, JSON.stringify(product, null, 2), 'utf8');
console.log('\nสินค้า', product.title, '·', items.length, product.unitName, '· รวม', items.reduce((s, i) => s + i.pages, 0), 'หน้า');
if (problems.length) { console.log('\n⚠️ ปัญหา:\n- ' + problems.join('\n- ')); process.exit(2); }
console.log('ต่อไป: ตั้งชื่อเล่มใน product.json (items[].name) ถ้ายังเป็นรหัส แล้วรัน node tools/build-site.mjs');
