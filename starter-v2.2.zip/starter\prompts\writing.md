# ชีทฝึกเขียน ก-ฮ / A-Z

1 หน้า = 1 ตัวอักษร · ชุดไทย 44 หน้า (ก-ฮ) หรือ 20 หน้า (ตัวที่ใช้บ่อย) · ชุดอังกฤษ 26 หน้า · ขาย 20 แบบ (ไทย หรือ อังกฤษ) 159 / 40 แบบครบ 2 ภาษา 199

## Prompt ต่อหน้า (แทน {ตัวอักษร} {คำ} {สิ่งของ})
```
Thai handwriting practice worksheet for kids, A4 portrait, clean printable black and white design. At the top: the Thai letter "{ตัวอักษร}" very large and bold with numbered stroke-order arrows, next to it the word "{คำ}" and a cute simple line-art {สิ่งของ} illustration. Below: 4 rows of dotted tracing letters "{ตัวอักษร}" on handwriting guide lines, the first letter of each row solid as an example, the rest dotted. A small line "ชื่อ ______  วันที่ ______" at the top right. White background, thick clean lines, no color, no shading. ONE single full-bleed page. Thai text must be spelled exactly as given.
```
อังกฤษ: เปลี่ยนเป็น `the English letter "{ตัว}" uppercase and lowercase "{ตัวเล็ก}"` และคำเป็นอังกฤษ

## ตรวจพิเศษ
- ตัวอักษรหัวเรื่องต้องเป็นตัวที่สั่งจริง หัวตัวอักษรถูกด้าน (ก ไม่กลายเป็น ถ)
- แถวเส้นประต้องเป็น**ตัวเดียวกัน**ซ้ำ ไม่มีตัวแปลกปนมา
- คำประกอบสะกดถูก (เช่น "ไก่" ไม่ใช่ "ไก")
- ถ้าตัวอักษรใดเจน 2 รอบยังผิด ให้ลดของในหน้า (ตัดรูปประกอบ) แล้วเจนใหม่
