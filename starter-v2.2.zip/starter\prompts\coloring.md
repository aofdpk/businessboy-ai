# สมุดระบายสีเด็ก

ค่าเริ่มต้น: เล่มละ 20 หน้า + ปก 1 · ธีมเดียวต่อเล่ม (ไดโนเสาร์ / ทะเล / อวกาศ / ฟาร์ม / ยานพาหนะ / เจ้าหญิง / ผลไม้ / แมลง / หุ่นยนต์ / สัตว์ไทย)

## Prompt หน้าใน (แทน {ธีม} {ฉาก} {คำบรรยาย})
```
Children's coloring book page, black and white line art only, clean bold outlines, pure white background, no shading, no gray, no color. A cute friendly {ธีม} {ฉาก}. Simple shapes suitable for ages 3-6, large areas to color, thick even lines. A small Thai caption "{คำบรรยาย}" in a simple rounded font at the bottom center. ONE single full-bleed page. NOT a grid, NOT a collage, NOT a character sheet, no extra panels, no watermark. Thai text must be spelled exactly as given.
```
คำบรรยายสั้น 2-5 คำ เช่น "ช้างน้อยเล่นน้ำ" · ถ้าไม่อยากมีคำบรรยาย ตัดประโยคนั้นออกได้

## ตัวอย่างฉาก 8 หน้าแรก (ธีมไดโนเสาร์) · เปลี่ยน "ฉาก" ทุกหน้า ตัวเอกเดิม
1. T-rex standing near a volcano and palm trees, smiling
2. Triceratops eating leaves from a bush
3. Long-neck dinosaur reaching up to a tall tree
4. Stegosaurus walking beside a river with fish
5. Pterodactyl flying over mountains and clouds
6. Baby dinosaur hatching from an egg in a nest
7. Dinosaur playing with a ball in a meadow with flowers
8. Dinosaur sleeping under the moon and stars
(เล่ม 20 หน้าให้คิดฉากต่อจนครบ ไม่ซ้ำกัน)

## Prompt ปก
```
Children's coloring book cover, black and white line art, one cute friendly {ธีม} centered, decorative simple border of leaves and stars, Thai title "{ชื่อเล่ม}" in large bold rounded kids font at the top, small Thai subtitle "ระบายสีได้ 20 หน้า" under the title, clean bold outlines, pure white background, no shading, no color. Thai text must be spelled exactly as given.
```

## ตรวจพิเศษสำหรับระบายสี
- ต้อง**ไม่มีสีและเงา**เลย ถ้ามีพื้นเทา = เจนใหม่
- เส้นต้องปิดสนิท (ระบายแล้วสีไม่ทะลุ)
- 1 ตัวเอกต่อหน้า ถ้าเห็น 3-4 ตัวเรียงกัน = collage เจนใหม่
- อ่านชื่อเล่ม/คำบรรยายทุกตัวอักษร
