# ชีทคณิตอนุบาล ป.1

โจทย์ต้อง**ถูก 100%** → Codex **คิดโจทย์และเฉลยเองด้วยโค้ดก่อน** แล้วใส่ตัวเลขที่ถูกลง prompt คำต่อคำ · AI มีหน้าที่วาดหน้าให้สวย ไม่ใช่คิดเลข

## โครงชุด (8 หน้า = ปก + แบบฝึก 6 + เฉลย 1)
1. นับภาพ เขียนเลข 1-5 · 2. นับภาพ 6-10 · 3. จับคู่ตัวเลขกับจำนวน · 4. บวกจากรูป (ผลไม่เกิน 10) · 5. ลบจากรูป · 6. เติมเลขที่หาย 1-20 · 7. **เฉลยทุกข้อ**
ระดับ: อนุบาล ไม่เกิน 10 · ป.1 ไม่เกิน 20

## Prompt หน้าแบบฝึก (ตัวอย่างหน้า "นับภาพ")
```
Kids math worksheet, A4 portrait, clean printable design, white background, thick clean lines, light playful style. Title at top: "นับภาพแล้วเขียนตัวเลข". Five rows, each row shows a group of cute simple {สิ่งของ} icons and an empty answer box on the right: row 1 has exactly 3 apples, row 2 has exactly 5 stars, row 3 has exactly 2 fish, row 4 has exactly 4 cars, row 5 has exactly 1 balloon. Small line "ชื่อ ______" at top right. ONE single page, no extra text. Thai text must be spelled exactly as given.
```
หน้าบวก/ลบ: ระบุโจทย์ทุกข้อเป็นตัวเลขตรงๆ เช่น `row 1: "3 + 2 = ___" shown with 3 apples plus 2 apples`

## Prompt หน้าเฉลย
```
Answer key page for a kids math worksheet, A4 portrait, clean simple layout, white background. Title "เฉลย". A neat list: "หน้า 1: 3, 5, 2, 4, 1", "หน้า 2: ...", ... in large clear Thai and numbers. No illustrations needed except a small star decoration. Thai text and numbers must be exactly as given.
```

## ตรวจพิเศษ (ห้ามข้าม)
- **นับรูปในทุกแถวเอง** ต้องตรงกับที่สั่ง (AI ชอบวาดเกิน/ขาด 1 ชิ้น) ผิด = เจนใหม่
- ตัวเลขในโจทย์และเฉลยตรงกับที่โค้ดคำนวณ
- ชื่อหัวเรื่อง/คำไทยสะกดถูก
