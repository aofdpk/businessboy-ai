// สร้างโครงสินค้าใหม่: node tools/init-product.mjs <slug> "<ชื่อสินค้า>" [อีโมจิ]
// ตัวอย่าง: node tools/init-product.mjs coloring-dino "สมุดระบายสีไดโนเสาร์" 🖍️
import fs from 'node:fs';
import path from 'node:path';

const [slug, title, emoji = '📄'] = process.argv.slice(2);
if (!slug || !title) {
  console.error('ใช้: node tools/init-product.mjs <slug-ภาษาอังกฤษ> "<ชื่อสินค้า>" [อีโมจิ]');
  process.exit(1);
}
if (!/^[a-z0-9-]+$/.test(slug)) { console.error('slug ต้องเป็น a-z 0-9 และขีด - เท่านั้น'); process.exit(1); }

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
const dir = path.join(root, 'products', slug);
for (const d of ['pages', 'files', 'thumbs', 'zips']) fs.mkdirSync(path.join(dir, d), { recursive: true });

const pj = path.join(dir, 'product.json');
if (fs.existsSync(pj)) { console.log('มี product.json อยู่แล้ว ไม่เขียนทับ:', pj); process.exit(0); }

const product = {
  slug, title, emoji,
  tagline: 'ไฟล์ PDF คมชัด ปริ้นซ้ำได้ไม่จำกัด · ดูตัวอย่างได้ครบทุกเล่มเลยค่ะ',
  note: 'ภาพที่เห็นเป็นตัวอย่าง 1 หน้า · ไฟล์จริงมีหลายหน้าเต็มทุกเล่ม',
  unitName: 'เล่ม',
  ratio: '3 / 4',
  items: [],
  promos: [
    { key: 'pro1', label: 'โปร 1 · 3 เล่ม', price: 159, items: [] },
    { key: 'pro2', label: 'โปร 2 · ครบทุกเล่ม', price: 199, best: true, items: 'all' }
  ]
};
fs.writeFileSync(pj, JSON.stringify(product, null, 2), 'utf8');
console.log('สร้างแล้ว:', path.relative(root, dir));
console.log('ต่อไป: เจนรูปหน้าใส่ products/' + slug + '/pages/<รหัสเล่ม>/p01.png p02.png ... (+ cover.png)');
console.log('แล้วรัน: node tools/finalize.mjs ' + slug);
