# สินค้าแบบ "เอกสารพิมพ์" ทั่วไป (ไอเดียที่ไม่อยู่ใน 5 ตระกูลที่มีสูตรเฉพาะ)

ใช้กับ: แพลนเนอร์ · แบบฟอร์มบัญชี · ป้ายราคา/ป้ายร้าน · เมนู · ใบงานภาษา · ใบงานผู้สูงอายุ · การ์ดอวยพร · ตารางเวร · chore chart · บทสวด · สมุดบันทึก ฯลฯ

## หลักการ: เจนทั้งหน้าเป็นรูปเดียว รวมตัวหนังสือไทย
ไม่ต้องทำ HTML แยก · เขียน prompt บรรยาย "หน้ากระดาษ" ให้ละเอียดเหมือนสั่งกราฟิกดีไซเนอร์: ชื่อหัวเรื่อง คอลัมน์/ช่อง จำนวนแถว ข้อความทุกคำที่ต้องมี ตำแหน่ง สี ฟอนต์ · ข้อความไทยทุกคำใส่ในเครื่องหมายคำพูดคำต่อคำ

## Prompt แบบตาราง/แบบฟอร์ม (ตัวอย่าง: บัญชีรายรับรายจ่าย)
```
Printable A4 portrait bookkeeping form for a small food vendor, clean modern design, white background with {สีหลัก} header bar. Title "บันทึกรายรับรายจ่ายประจำวัน" large at the top, below it "วันที่ ______  ร้าน ______". A table with 6 columns headed "รายการ", "รายรับ", "รายจ่าย", "คงเหลือ", "หมายเหตุ", "✓" and 15 empty rows tall enough to handwrite. At the bottom a summary box with "รวมรายรับ ______", "รวมรายจ่าย ______", "กำไรวันนี้ ______" in bold. Small cute {ไอคอน} decoration at the corner. Clear readable Thai font, thin table lines, no other text. ONE single page. Thai text must be spelled exactly as given.
```

## Prompt แบบป้าย (ตัวอย่าง: ป้ายราคา)
```
Printable A4 portrait price sign for a Thai street-food stall, bold eye-catching design, {สี} background. Big Thai text "{ชื่อเมนู}" at the top, huge price "{ราคา} บาท" in the center, small line "{คำโปรย}" below, a cute flat illustration of {อาหาร} on the side. High contrast, readable from 3 meters, no extra text. ONE single page. Thai text must be spelled exactly as given.
```
ทำชุดใหญ่ = เปลี่ยนแค่ชื่อเมนู/ราคา/สี ทีละหน้า (50 แบบ = 50 prompt ที่เปลี่ยนตัวแปร)

## Prompt แบบใบงาน (ช่องกรอก + เส้นประ)
```
Printable A4 worksheet for {กลุ่ม}, title "{หัวเรื่อง}" at top, clear instruction line "{คำสั่ง}", then {N} numbered exercises each with {รายละเอียด} and an empty answer line, large readable Thai font (at least {ขนาด}), white background, light decorative border of {ธีม}. ONE single page. Thai text must be spelled exactly as given.
```

## โครง "1 ชุด" ที่ขายได้
- ต้องเป็น **ชุดใหญ่ใช้ซ้ำได้** ไม่ใช่แผ่นเดียว: แพลนเนอร์ = 12 เดือน + สรุปปี + เป้าหมาย · ป้าย = 50 แบบ 5 ธีม · แบบฟอร์ม = 20 แบบ (รายวัน/รายสัปดาห์/รายเดือน/สต๊อก/ต้นทุน...) · ใบงาน = 20 แบบ × 6-10 หน้า
- ทุกชุดมีหน้า "วิธีใช้" 1 หน้า และ (ถ้ามีคำตอบ) หน้าเฉลย
- ตัวหนังสือใหญ่พอสำหรับกลุ่มเป้าหมาย (ผู้สูงอายุใหญ่มาก · เด็กเล็กใหญ่)

## QC เพิ่มเติม
- อ่านข้อความไทย**ทุกคำทุกช่อง** สะกดถูก ไม่มีคำแปลกที่ AI แถม (ชอบแถมคำอังกฤษหรือตัวอักษรมั่ว) ผิด = เจนใหม่หน้านั้น
- นับคอลัมน์/แถวให้ตรงที่สั่ง ช่องกรอกมีขนาดเขียนมือได้จริง
- ตัวเลข/ราคาตรงที่สั่ง
