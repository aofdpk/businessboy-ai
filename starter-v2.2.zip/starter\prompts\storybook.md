# นิทานภาพสอนใจ

เรื่องละ 10 หน้า + ปก · ภาพสีน้ำ · ตัวละครเดิมทั้งเรื่อง · **ข้อความนิทานอยู่ในรูปเลย** (แถบล่าง)

## ขั้น 1 เขียนบทก่อน (Codex เขียนเอง แล้วโชว์ให้ผู้ใช้ดู)
- ตัวเอก 1 ตัว ลักษณะล็อกตาย เช่น "กระต่ายสีขาว หูยาวปลายชมพู ผ้าพันคอสีฟ้า"
- 1 หน้า = 1 เหตุการณ์ + ข้อความ 1-2 ประโยคสั้น (ไม่เกิน 40 คำ ต่อหน้า)
- หน้าสุดท้าย = ข้อคิด 1 บรรทัด

## ขั้น 2 เจนภาพ (ใส่ลักษณะตัวเอกซ้ำทุกหน้า คำต่อคำ + ข้อความของหน้านั้น)
```
Children's picture book page, soft watercolor style, warm gentle colors, portrait. {ลักษณะตัวเอกแบบเต็ม} {เหตุการณ์ของหน้านี้}. Only ONE {ตัวเอก} in the entire picture, no duplicate characters. At the bottom, a soft cream text band with the Thai story text "{ข้อความหน้านี้}" in a clear rounded children's font, comfortably readable. ONE single full-bleed page, no panels, no border. Thai text must be spelled exactly as given.
```
ตัวอย่างลักษณะที่ล็อก: `a small white rabbit with long ears with pink tips, wearing a light-blue scarf, big round black eyes`

## Prompt ปก
```
Children's picture book cover, soft watercolor style, {ลักษณะตัวเอก} centered in a cheerful scene, Thai title "{ชื่อเรื่อง}" in large bold rounded kids font at the top, small Thai subtitle "นิทานสอนใจ" below the title. Only ONE main character. Thai text must be spelled exactly as given.
```

## ตรวจพิเศษ
- ตัวเอกหน้าตา/สี/เครื่องแต่งกายเหมือนกันทุกหน้า (identity drift = เจนใหม่)
- **ตัวเอกต้องมีตัวเดียวในภาพ** ถ้ามี 2-3 ตัว = เจนใหม่ (เกิดบ่อยมาก)
- อ่านข้อความนิทานทุกคำในทุกหน้า ต้องตรงบทเป๊ะ สระวรรณยุกต์ครบ
