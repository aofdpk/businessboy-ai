โฟลเดอร์สินค้า · แต่ละสินค้า = 1 โฟลเดอร์ (สร้างด้วย `node tools/init-product.mjs <slug> "<ชื่อ>"`)

```
<slug>/
  product.json     ชื่อ แท็กไลน์ รายชื่อเล่ม โปรราคา
  pages/<เล่ม>/    cover.png p01.png p02.png ...   ← ที่เจนรูปมาวาง
  files/           PDF (finalize สร้างให้)
  thumbs/          รูปย่อ (finalize สร้างให้)
  zips/            zip ต่อโปร (finalize สร้างให้)
```
