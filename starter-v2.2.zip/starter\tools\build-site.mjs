// สร้างเว็บจาก ref/ + site.config.json + products/<slug>/product.json → site/
// ใช้: node tools/build-site.mjs   (อ่าน product จาก site.config.json)
// เทมเพลต: ref/sample-site.html (หน้าตัวอย่าง) และ ref/delivery.html (หน้าโหลด)
//   {{key}} = แทนค่า · {{#items}}...{{/items}} = วนซ้ำ · {{#best}}...{{/best}} = แสดงเมื่อจริง
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')), '..');
const cfg = JSON.parse(fs.readFileSync(path.join(root, 'site.config.json'), 'utf8'));
const slug = process.argv[2] || cfg.product;
const pdir = path.join(root, 'products', slug);
const product = JSON.parse(fs.readFileSync(path.join(pdir, 'product.json'), 'utf8'));
if (!product.items?.length) { console.error('product.json ยังไม่มี items → รัน finalize ก่อน'); process.exit(1); }

const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// ---- template engine เล็กๆ ----
function render(tpl, data) {
  tpl = tpl.replace(/\{\{#(\w+)\}\}([\s\S]*?)\{\{\/\1\}\}/g, (_, k, inner) => {
    const v = data[k];
    if (Array.isArray(v)) return v.map(item => render(inner, { ...data, ...item })).join('');
    return v ? render(inner, data) : '';
  });
  return tpl.replace(/\{\{(\w+)\}\}/g, (_, k) => (k in data ? (data[k] ?? '') : ''));
}

const theme = cfg.theme || {};
const themeCss = ':root{' + Object.entries(theme).map(([k, v]) => `--${k}:${v}`).join(';') + '}';
const out = path.join(root, 'site', slug); // โฟลเดอร์ = slug → Vercel ตั้งชื่อโปรเจกต์ตามนี้อัตโนมัติ
fs.rmSync(out, { recursive: true, force: true });
for (const d of ['files', 'thumbs', 'zip']) fs.mkdirSync(path.join(out, d), { recursive: true });

// copy assets
for (const i of product.items) {
  fs.copyFileSync(path.join(pdir, i.file), path.join(out, i.file));
  fs.copyFileSync(path.join(pdir, i.thumb), path.join(out, i.thumb));
}
for (const p of product.promos) fs.copyFileSync(path.join(pdir, 'zips', p.key + '.zip'), path.join(out, 'zip', p.key + '.zip'));

const base = {
  themeCss, shopName: esc(cfg.shop?.name || ''), cta: esc(cfg.shop?.cta || 'ทักแชทสั่งเลย'),
  title: esc(product.title), emoji: product.emoji || '', tagline: esc(product.tagline), note: esc(product.note),
  ratio: product.ratio || '3 / 4', unitName: esc(product.unitName || 'เล่ม'), watermark: esc(cfg.watermark || 'ตัวอย่าง'),
};

// หน้าตัวอย่าง
const items = product.items.map(i => ({ id: i.id, name: esc(i.name), thumb: i.thumb, pages: i.pages, pagesLabel: i.pages > 1 ? `📄 ${base.unitName}จริง ${i.pages} หน้า` : '' }));
const prices = product.promos.map(p => ({ label: esc(p.label), price: p.price, best: !!p.best }));
fs.writeFileSync(path.join(out, 'index.html'), render(fs.readFileSync(path.join(root, 'ref', 'sample-site.html'), 'utf8'), { ...base, items, prices }), 'utf8');

// หน้าโหลดต่อโปร
for (const p of product.promos) {
  const list = (p.items === 'all' ? product.items : product.items.filter(i => p.items.includes(i.id)))
    .map(i => ({ name: esc(i.name), thumb: i.thumb, file: i.file, dl: esc(i.dl) }));
  const html = render(fs.readFileSync(path.join(root, 'ref', 'delivery.html'), 'utf8'), {
    ...base, promoLabel: esc(p.label), count: list.length, zip: 'zip/' + p.key + '.zip',
    zipName: esc((product.title + '-' + p.label).replace(/[\\/:*?"<>|·]/g, '-').replace(/\s+/g, '') + '.zip'), items: list,
  });
  fs.writeFileSync(path.join(out, p.key + '.html'), html, 'utf8');
}
fs.writeFileSync(path.join(out, 'vercel.json'), JSON.stringify({ cleanUrls: true, trailingSlash: false }, null, 2), 'utf8');

const size = (function walk(d) { return fs.readdirSync(d).reduce((s, f) => { const p = path.join(d, f); return s + (fs.statSync(p).isDirectory() ? walk(p) : fs.statSync(p).size); }, 0); })(out);
console.log('✓ สร้าง site/' + slug + '/ แล้ว ·', product.items.length, product.unitName, '·', product.promos.map(p => '/' + p.key).join(' '), '·', (size / 1e6).toFixed(1) + 'MB');
console.log('ดูในเครื่อง: npx serve site/' + slug + '   · ขึ้นเว็บ: cd site/' + slug + ' && npx vercel --prod --yes');
