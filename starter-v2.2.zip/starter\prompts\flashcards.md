# แฟลชการ์ดคำศัพท์ 2 ภาษา

1 ไฟล์ = 1 หมวด (สัตว์ / ผลไม้ / ยานพาหนะ / สี / อาชีพ / ร่างกาย / ของใช้ / อาหาร) · หมวดละ 1 หน้า A4 = 9 ใบ (ตัด 3x3) หรือทำ 2 หน้า = 18 ใบ · แต่ละหมวดทำ 2 ฉบับ: อังกฤษเด่น + ไทยเด่น

## Prompt ต่อหน้า (แทน {หมวด} และรายการ 9 คำ)
```
Printable kids flashcard sheet, A4 portrait, a neat 3x3 grid of 9 equal cards with dotted cut lines between them, white background. Each card: a cute flat-vector illustration in the same consistent style, the English word in large bold letters and the Thai word in smaller text below it. The 9 cards in order: 1 "Cat" "แมว", 2 "Dog" "หมา", 3 "Elephant" "ช้าง", 4 "Rabbit" "กระต่าย", 5 "Bird" "นก", 6 "Fish" "ปลา", 7 "Cow" "วัว", 8 "Pig" "หมู", 9 "Duck" "เป็ด". Bright soft colors, thick clean outlines, no extra text, no border around the page. Thai and English text must be spelled exactly as given.
```
ฉบับไทยเด่น: สลับให้ `the Thai word in large bold letters and the English word smaller below`

## ตรวจพิเศษ
- นับให้ครบ 9 ช่อง ช่องเท่ากัน มีเส้นประตัด
- อ่านทั้ง 18 คำ (ไทย 9 อังกฤษ 9) ทุกตัวอักษร · รูปตรงกับคำ (ไม่ใช่ "แมว" แต่รูปเป็นหมา)
- สไตล์รูปเหมือนกันทั้ง 9 ใบ ถ้าใบไหนหลุดสไตล์ชัด = เจนใหม่ทั้งหน้า
